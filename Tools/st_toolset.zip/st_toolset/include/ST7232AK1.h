/* ST7232AK1.h */
#ifdef MCU_NAME
#define ST7232AK1 1
#endif
#include "ST7232A.h"
