/* STM8AF6248.h */
#ifdef MCU_NAME
#define STM8AF6248 1
#endif
#include "STM8AF6168.h"
