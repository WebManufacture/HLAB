/* ST7FLIT10BF1.h */
#ifdef MCU_NAME
#define ST7FLIT10BF1 1
#endif
#include "ST7LITE10B.h"
