/* ST72_F_361K7.h */
#ifdef MCU_NAME
#define ST72_F_361K7 1
#endif
#include "ST72361K.h"
