/* ST7263BE2.h */
#ifdef MCU_NAME
#define ST7263BE2 1
#endif
#include "ST7263BE.h"
