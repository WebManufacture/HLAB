/* ST7FLITEUSICD.h */
#ifdef MCU_NAME
#define ST7FLITEUSICD 1
#endif
#include "ST7FLITEUS5.h"
