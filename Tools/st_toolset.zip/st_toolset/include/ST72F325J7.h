/* ST72F325J7.h */
#ifdef MCU_NAME
#define ST72F325J7 1
#endif
#include "ST72325.h"
