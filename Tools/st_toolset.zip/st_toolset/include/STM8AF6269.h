/* STM8AF6269.h */
#ifdef MCU_NAME
#define STM8AF6269 1
#endif
#include "STM8AF61x9.h"
