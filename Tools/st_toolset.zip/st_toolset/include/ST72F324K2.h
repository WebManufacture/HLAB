/* ST72F324K2.h */
#ifdef MCU_NAME
#define ST72F324K2 1
#endif
#include "ST72324.h"
