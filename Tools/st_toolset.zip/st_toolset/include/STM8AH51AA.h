/* STM8AH51AA.h */
#ifdef MCU_NAME
#define STM8AH51AA 1
#endif
#include "STM8AF51xA.h"
