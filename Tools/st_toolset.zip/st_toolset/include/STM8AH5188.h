/* STM8AH5188.h */
#ifdef MCU_NAME
#define STM8AH5188 1
#endif
#include "STM8AF51x8.h"
