/* STM8AF62A6.h */
#ifdef MCU_NAME
#define STM8AF62A6 1
#endif
#include "STM8AF61x6.h"
