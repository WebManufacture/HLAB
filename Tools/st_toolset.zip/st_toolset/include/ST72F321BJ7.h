/* ST72F321BJ7.h */
#ifdef MCU_NAME
#define ST72F321BJ7 1
#endif
#include "ST72321.h"
