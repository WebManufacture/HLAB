/* ST72F321M9.h */
#ifdef MCU_NAME
#define ST72F321M9 1
#endif
#include "ST72F321M6.h"
