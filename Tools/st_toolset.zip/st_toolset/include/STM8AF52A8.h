/* STM8AF52A8.h */
#ifdef MCU_NAME
#define STM8AF52A8 1
#endif
#include "STM8AF51x8.h"
