/* STM8AF6188.h */
#ifdef MCU_NAME
#define STM8AF6188 1
#endif
#include "STM8AF61x8.h"
