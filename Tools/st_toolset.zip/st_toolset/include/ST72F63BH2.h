/* ST72F63BH2.h */
#ifdef MCU_NAME
#define ST72F63BH2 1
#endif
#include "ST7263BH.h"
