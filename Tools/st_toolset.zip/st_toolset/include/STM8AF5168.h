/* STM8AF5168.h */
#ifdef MCU_NAME
#define STM8AF5168 1
#endif
#include "STM8AF51x8.h"
