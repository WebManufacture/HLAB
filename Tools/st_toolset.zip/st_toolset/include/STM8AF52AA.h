/* STM8AF52AA.h */
#ifdef MCU_NAME
#define STM8AF52AA 1
#endif
#include "STM8AF51xA.h"
