/* ST7FLIT10BF0.h */
#ifdef MCU_NAME
#define ST7FLIT10BF0 1
#endif
#include "ST7LITE10B.h"
