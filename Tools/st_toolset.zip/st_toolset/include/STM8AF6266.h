/* STM8AF6266.h */
#ifdef MCU_NAME
#define STM8AF6266 1
#endif
#include "STM8AF61x6.h"
