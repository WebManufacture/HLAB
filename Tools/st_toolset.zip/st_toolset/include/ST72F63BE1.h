/* ST72F63BE1.h */
#ifdef MCU_NAME
#define ST72F63BE1 1
#endif
#include "ST7263BE.h"
