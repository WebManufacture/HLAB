/* ST72F63BE2.h */
#ifdef MCU_NAME
#define ST72F63BE2 1
#endif
#include "ST7263BE.h"
