/* STM8AH6179.h */
#ifdef MCU_NAME
#define STM8AH6179 1
#endif
#include "STM8AF61x9.h"
