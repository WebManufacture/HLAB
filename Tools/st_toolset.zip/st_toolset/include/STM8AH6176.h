/* STM8AH6176.h */
#ifdef MCU_NAME
#define STM8AH6176 1
#endif
#include "STM8AF61x6.h"
