/* ST72F63BK2.h */
#ifdef MCU_NAME
#define ST72F63BK2 1
#endif
#include "ST7263BK2.h"
