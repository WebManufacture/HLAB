/* ST72321J9.h */
#ifdef MCU_NAME
#define ST72321J9 1
#endif
#include "ST72321.h"
