/* STM8AF6288.h */
#ifdef MCU_NAME
#define STM8AF6288 1
#endif
#include "STM8AF61x8.h"
