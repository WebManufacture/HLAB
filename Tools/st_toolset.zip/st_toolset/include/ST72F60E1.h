/* ST72F60E1.h */
#ifdef MCU_NAME
#define ST72F60E1 1
#endif
#include "ST7260.h"
