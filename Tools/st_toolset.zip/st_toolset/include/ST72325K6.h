/* ST72325K6.h */
#ifdef MCU_NAME
#define ST72325K6 1
#endif
#include "ST72325.h"
