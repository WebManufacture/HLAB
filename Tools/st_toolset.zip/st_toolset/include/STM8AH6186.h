/* STM8AH6186.h */
#ifdef MCU_NAME
#define STM8AH6186 1
#endif
#include "STM8AF61x6.h"
