/* ST72F321B_A_R9.h */
#ifdef MCU_NAME
#define ST72F321B_A_R9 1
#endif
#include "ST72321.h"
