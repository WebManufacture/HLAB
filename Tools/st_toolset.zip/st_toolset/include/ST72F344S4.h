/* ST72F344S4.h */
#ifdef MCU_NAME
#define ST72F344S4 1
#endif
#include "ST72344.h"
