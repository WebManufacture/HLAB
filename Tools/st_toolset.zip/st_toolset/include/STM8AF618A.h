/* STM8AF618A.h */
#ifdef MCU_NAME
#define STM8AF618A 1
#endif
#include "STM8AF61xA.h"
