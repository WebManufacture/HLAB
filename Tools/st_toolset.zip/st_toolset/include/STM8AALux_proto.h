/* STM8AALux_proto.h */
#ifdef MCU_NAME
#define STM8AALux_proto 1
#endif
#include "STM8AF61x6.h"
