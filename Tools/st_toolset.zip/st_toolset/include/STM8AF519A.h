/* STM8AF519A.h */
#ifdef MCU_NAME
#define STM8AF519A 1
#endif
#include "STM8AF51xA.h"
