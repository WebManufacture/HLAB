/* STM8AF6146.h */
#ifdef MCU_NAME
#define STM8AF6146 1
#endif
#include "STM8AF61x6.h"
