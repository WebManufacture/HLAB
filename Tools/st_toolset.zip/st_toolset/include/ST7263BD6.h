/* ST7263BD6.h */
#ifdef MCU_NAME
#define ST7263BD6 1
#endif
#include "ST7263BH.h"
