/* ST72_F_361J9.h */
#ifdef MCU_NAME
#define ST72_F_361J9 1
#endif
#include "ST72361AR.h"
