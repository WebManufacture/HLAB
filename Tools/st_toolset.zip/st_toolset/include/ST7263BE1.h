/* ST7263BE1.h */
#ifdef MCU_NAME
#define ST7263BE1 1
#endif
#include "ST7263BE.h"
