/* ST72F63BK4.h */
#ifdef MCU_NAME
#define ST72F63BK4 1
#endif
#include "ST7263BK6.h"
