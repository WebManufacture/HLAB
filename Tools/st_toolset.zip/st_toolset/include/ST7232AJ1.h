/* ST7232AJ1.h */
#ifdef MCU_NAME
#define ST7232AJ1 1
#endif
#include "ST7232A.h"
