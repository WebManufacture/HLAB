/* STM8AH6168.h */
#ifdef MCU_NAME
#define STM8AH6168 1
#endif
#include "STM8AF6168.h"
