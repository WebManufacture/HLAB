/* STM8AF528A.h */
#ifdef MCU_NAME
#define STM8AF528A 1
#endif
#include "STM8AF51xA.h"
