/* STM8AF51A8.h */
#ifdef MCU_NAME
#define STM8AF51A8 1
#endif
#include "STM8AF51x8.h"
