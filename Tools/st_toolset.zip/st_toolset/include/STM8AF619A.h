/* STM8AF619A.h */
#ifdef MCU_NAME
#define STM8AF619A 1
#endif
#include "STM8AF61xA.h"
