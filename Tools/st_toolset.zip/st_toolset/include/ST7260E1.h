/* ST7260E1.h */
#ifdef MCU_NAME
#define ST7260E1 1
#endif
#include "ST7260.h"
