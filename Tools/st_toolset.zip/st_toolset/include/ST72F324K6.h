/* ST72F324K6.h */
#ifdef MCU_NAME
#define ST72F324K6 1
#endif
#include "ST72324.h"
