
					IMPORTANT
					=========

		AS THE PROCEDURE IS NOT DONE AUTOMATICALLY AFTER YOU SENT YOUR
		REGISTRATION INFORMATIONS, IT COULD TAKE A FEW HOURS OR A FEW DAYS
		(AFTER THE WEEK-END) ACCORDING TO YOUR LOCATION AND TIME BEFORE
		YOU RECEIVE YOUR LICENSE FILE. THANK YOUR FOR YOUR UNDERSTANDING.

					*********

			STM8-16K : Description of the 16K Limitation:

		The 16K limitation is applied to all the components allocated to
		the flash space, meaning basically code and constants.
		This limitation also allows 1K of data, so the complete
		application can be 17K.

					IMPORTANT
					=========

		PLEASE NOTE THAT THE 16K VERSION YOU ARE USING DOES NOT INCLUDE
		DIRECT SUPPORT (NO MAIL, NO PHONE). IF YOU HAVE ANY QUESTION,
		PLEASE POST THEM ON WWW.STMCU.COM.
